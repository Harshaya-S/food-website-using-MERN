import React from 'react'

export default function Caraousel() {
  return (
    // https://source.unsplash.com/random/900×700/?burger
    <div>
    </div>
  )
}
