# FoodyWeb
Foody Web is a Dynamic Website For Food Ordering developed using MERN
